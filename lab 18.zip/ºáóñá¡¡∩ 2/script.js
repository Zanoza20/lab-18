var input = "Java Script";
var output = input.replace(/(\w+)\s(\w+)/, '$2, $1');
console.log(output);
