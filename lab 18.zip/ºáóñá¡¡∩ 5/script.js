function checkLogin(login) {
  var regex = /^[A-Za-z][A-Za-z0-9]{1,9}$/;
  var numbers = login.match(/\d+(\.\d+)?/g);

  if (regex.test(login)) {
    console.log("Login is valid");
    if (numbers) {
      console.log(numbers.join(', '));
    }
  } else {
    console.log("Login is not valid");
    if (numbers) {
      console.log(numbers.join(', '));
    }
  }
}

checkLogin('ee1.1ret3');
checkLogin('ee1*1ret3');
