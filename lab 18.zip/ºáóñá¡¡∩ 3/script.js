function validateCardNumber(cardNumber) {
  var regex = /^\d{4}-\d{4}-\d{4}-\d{4}$/;

  if (regex.test(cardNumber)) {
    console.log("Bank card number is valid");
  } else {
    console.log("Bank card number is not valid");
  }
}

validateCardNumber('9999-9999-9999-9999');
